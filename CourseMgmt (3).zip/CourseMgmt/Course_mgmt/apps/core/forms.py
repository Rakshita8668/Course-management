from django import forms

from .models import (
    Assessment,
    Attendance,
    Batch,
    Certificate,
    Client,
    Course,
    Enrollment,
    Material,
    Module,
    Program,
    ProgramCourse,
    Session,
)

INPUT_CLASS = 'p-input'


def _style_model_form(form):
    for field in form.fields.values():
        if isinstance(field.widget, (forms.Select, forms.DateInput)):
            field.widget.attrs['class'] = INPUT_CLASS
        else:
            field.widget.attrs.setdefault('class', INPUT_CLASS)


class ClientForm(forms.ModelForm):
    class Meta:
        model = Client
        fields = [
            'client_code',
            'client_name',
            'org_type',
            'contact_person',
            'designation',
            'email',
            'phone',
            'address',
            'city',
            'state',
            'pincode',
            'status',
            'notes',
        ]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        _style_model_form(self)


class CourseForm(forms.ModelForm):
    class Meta:
        model = Course
        fields = [
            'course_code',
            'course_name',
            'level',
            'duration_hours',
            'fees',
            'delivery_mode',
            'status',
            'description',
        ]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        _style_model_form(self)


class ProgramForm(forms.ModelForm):
    class Meta:
        model = Program
        fields = [
            'program_code',
            'program_name',
            'category',
            'program_type',
            'duration_days',
            'start_date',
            'end_date',
            'status',
            'description',
            'client',
        ]
        widgets = {
            'start_date': forms.DateInput(attrs={'type': 'date', 'class': INPUT_CLASS}),
            'end_date':   forms.DateInput(attrs={'type': 'date', 'class': INPUT_CLASS}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['client'].required = False
        self.fields['client'].empty_label = '— No client —'
        self.fields['client'].queryset = Client.objects.order_by('client_name')
        _style_model_form(self)


class BatchForm(forms.ModelForm):
    class Meta:
        model = Batch
        fields = [
            'batch_name',
            'client',
            'program',
            'course',
            'capacity',
            'start_date',
            'end_date',
            'status',
            'remarks',
        ]
        widgets = {
            'start_date': forms.DateInput(attrs={'type': 'date', 'class': INPUT_CLASS}),
            'end_date':   forms.DateInput(attrs={'type': 'date', 'class': INPUT_CLASS}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['batch_name'].widget.attrs['readonly'] = True
        self.fields['client'].required = False
        self.fields['client'].empty_label = '— Select Client —'
        self.fields['client'].queryset = Client.objects.order_by('client_name')
        self.fields['program'].required = False
        self.fields['program'].empty_label = '— Select Program —'
        self.fields['program'].queryset = Program.objects.order_by('program_name')
        self.fields['course'].queryset = Course.objects.order_by('course_name')
        _style_model_form(self)


class ModuleForm(forms.ModelForm):
    class Meta:
        model = Module
        fields = ['course', 'name', 'duration_hours', 'status', 'description']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        _style_model_form(self)


class SessionForm(forms.ModelForm):
    class Meta:
        model = Session
        fields = ['course', 'title', 'instructor', 'start_date', 'end_date', 'status', 'notes']
        widgets = {
            'start_date': forms.DateInput(attrs={'type': 'date', 'class': INPUT_CLASS}),
            'end_date':   forms.DateInput(attrs={'type': 'date', 'class': INPUT_CLASS}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        _style_model_form(self)


class EnrollmentForm(forms.ModelForm):
    class Meta:
        model = Enrollment
        fields = ['student_name', 'course', 'enrollment_date', 'status']
        widgets = {
            'enrollment_date': forms.DateInput(attrs={'type': 'date', 'class': INPUT_CLASS}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        _style_model_form(self)


class MaterialForm(forms.ModelForm):
    class Meta:
        model = Material
        fields = [
            'training_module',
            'title',
            'description',
            'material_type',
            'resource_url',
            'uploaded_file',
            'author',
            'status',
        ]
        widgets = {
            'description': forms.Textarea(attrs={'rows': 4, 'class': INPUT_CLASS}),
            'resource_url': forms.URLInput(attrs={'class': INPUT_CLASS}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['training_module'].queryset = Module.objects.order_by('course__course_name', 'name')
        self.fields['training_module'].empty_label = '— Select Module —'
        self.fields['material_type'].empty_label = '— Select Material Type —'
        _style_model_form(self)

    def clean(self):
        cleaned_data = super().clean()
        resource_url = cleaned_data.get('resource_url')
        uploaded_file = cleaned_data.get('uploaded_file')
        has_existing_file = self.instance and self.instance.pk and self.instance.uploaded_file
        if not resource_url and not uploaded_file and not has_existing_file:
            raise forms.ValidationError('Please provide a resource URL or upload a file.')
        training_module = cleaned_data.get('training_module')
        if not training_module:
            raise forms.ValidationError('Please select a training module.')
        return cleaned_data


class CertificateForm(forms.ModelForm):
    class Meta:
        model = Certificate
        fields = ['student_name', 'course', 'issue_date', 'remarks']
        widgets = {
            'issue_date': forms.DateInput(attrs={'type': 'date', 'class': INPUT_CLASS}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        _style_model_form(self)


class AssessmentForm(forms.ModelForm):
    class Meta:
        model = Assessment
        fields = ['course', 'name', 'total_marks', 'status', 'scheduled_date']
        widgets = {
            'scheduled_date': forms.DateInput(attrs={'type': 'date', 'class': INPUT_CLASS}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        _style_model_form(self)


class AttendanceForm(forms.ModelForm):
    class Meta:
        model = Attendance
        fields = ['session', 'date', 'present_count', 'absent_count']
        widgets = {
            'date': forms.DateInput(attrs={'type': 'date', 'class': INPUT_CLASS}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        _style_model_form(self)


class ProgramCourseForm(forms.ModelForm):
    class Meta:
        model = ProgramCourse
        fields = ['program', 'course', 'sequence_no']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        _style_model_form(self)