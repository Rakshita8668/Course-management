from django.urls import path


from . import views

urlpatterns = [
    # ── LOgin/Logout/Dashboard ──────────────────────────────────────────

    path('', views.login_view, name='login'),
    path('dashboard/', views.dashboard_view, name='dashboard'),
    path('logout/', views.logout_view, name='logout'),

    # ── Courses ──────────────────────────────────────────
    path('courses/',                        views.CourseListView.as_view(),   name='course_list'),
    path('courses/add/',                    views.CourseCreateView.as_view(), name='course_add'),
    path('courses/<int:pk>/edit/',          views.CourseUpdateView.as_view(), name='course_edit'),
    path('courses/<int:pk>/delete/',        views.CourseDeleteView.as_view(), name='course_delete'),
    path('courses/search/',                 views.CourseSearchView.as_view(), name='search_course'),

    # ── Programs ─────────────────────────────────────────
    path('programs/',                       views.ProgramListView.as_view(),   name='program_list'),
    path('programs/add/',                   views.ProgramCreateView.as_view(), name='program_add'),
    path('programs/<int:pk>/edit/',         views.ProgramUpdateView.as_view(), name='program_edit'),
    path('programs/<int:pk>/delete/',       views.ProgramDeleteView.as_view(), name='program_delete'),
    path('programs/<int:pk>/',              views.ProgramDetailView.as_view(), name='program_detail'),
    path('programs/search/',               views.ProgramSearchView.as_view(), name='program_search'),

    # ── Clients ──────────────────────────────────────────
    path('clients/',                        views.ClientListView.as_view(),   name='client_list'),
    path('clients/add/',                    views.ClientCreateView.as_view(), name='client_add'),
    path('clients/<int:pk>/edit/',          views.ClientUpdateView.as_view(), name='client_edit'),
    path('clients/<int:pk>/delete/',        views.ClientDeleteView.as_view(), name='client_delete'),
    path('clients/search/',                 views.ClientSearchView.as_view(), name='client_search'),

    # ── Batches ──────────────────────────────────────────
    path('batches/',                        views.BatchListView.as_view(),   name='batch_list'),
    path('batches/add/',                    views.BatchCreateView.as_view(), name='batch_add'),
    path('batches/<int:pk>/edit/',          views.BatchUpdateView.as_view(), name='batch_edit'),
    path('batches/<int:pk>/delete/',        views.BatchDeleteView.as_view(), name='batch_delete'),

    # ── Modules ──────────────────────────────────────────
    path('modules/',                        views.ModuleListView.as_view(),   name='module_list'),
    path('modules/add/',                    views.ModuleCreateView.as_view(), name='module_add'),
    path('modules/<int:pk>/edit/',          views.ModuleUpdateView.as_view(), name='module_edit'),
    path('modules/<int:pk>/delete/',        views.ModuleDeleteView.as_view(), name='module_delete'),

    # ── Sessions ─────────────────────────────────────────
    path('sessions/',                       views.SessionListView.as_view(),   name='session_list'),
    path('sessions/add/',                   views.SessionCreateView.as_view(), name='session_add'),
    path('sessions/<int:pk>/edit/',         views.SessionUpdateView.as_view(), name='session_edit'),
    path('sessions/<int:pk>/delete/',       views.SessionDeleteView.as_view(), name='session_delete'),

    # ── Enrollments ──────────────────────────────────────
    path('enrollments/',                    views.EnrollmentListView.as_view(),   name='enrollment_list'),
    path('enrollments/add/',                views.EnrollmentCreateView.as_view(), name='enrollment_add'),
    path('enrollments/<int:pk>/edit/',      views.EnrollmentUpdateView.as_view(), name='enrollment_edit'),
    path('enrollments/<int:pk>/delete/',    views.EnrollmentDeleteView.as_view(), name='enrollment_delete'),

    # ── Materials ────────────────────────────────────────
    path('materials/',                      views.material_list,   name='material_list'),
    path('materials/upload/',               views.material_create, name='material_upload'),
    path('materials/<int:pk>/edit/',        views.material_edit,   name='material_edit'),
    path('materials/<int:pk>/',             views.material_detail, name='material_detail'),
    path('materials/<int:pk>/delete/',      views.material_delete, name='material_delete'),
    path('materials/<int:pk>/download/',    views.material_download, name='material_download'),

    # ── Certificates ─────────────────────────────────────
    path('certificates/',                   views.CertificateListView.as_view(),  name='certificate_list'),
    path('certificates/generate/',          views.CertificateCreateView.as_view(), name='generate_certificate'),

    # ── Assessments ──────────────────────────────────────
    path('assessments/',                    views.AssessmentListView.as_view(),   name='assessment_list'),
    path('assessments/add/',                views.AssessmentCreateView.as_view(), name='assessment_add'),
    path('assessments/<int:pk>/edit/',      views.AssessmentUpdateView.as_view(), name='assessment_edit'),
    path('assessments/<int:pk>/delete/',    views.AssessmentDeleteView.as_view(), name='assessment_delete'),
    path('assessments/results/',            views.ResultListView.as_view(),       name='result_list'),

    # ── Attendance ───────────────────────────────────────
    path('attendance/',                     views.AttendanceListView.as_view(),  name='attendance_list'),
    path('attendance/mark/',                views.MarkAttendanceView.as_view(),  name='mark_attendance'),
    path('attendance/report/',              views.AttendanceReportView.as_view(), name='attendance_report'),

    # ── Shared services ──────────────────────────────────
    path('shared/dashboard/',              views.SharedDashboardView.as_view(),      name='shared_dashboard'),
    path('shared/reports/',                views.SharedReportsView.as_view(),         name='shared_reports'),
    path('shared/notifications/',          views.SharedNotificationsView.as_view(),   name='shared_notifications'),
    path('shared/audit/',                  views.SharedAuditLogView.as_view(),        name='shared_audit'),
]