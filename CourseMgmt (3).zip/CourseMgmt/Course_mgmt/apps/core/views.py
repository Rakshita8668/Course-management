import os
from django.db.models import Q
import json
import datetime
from django.urls import reverse_lazy
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate,login
from django.contrib.auth import logout
from django.http import FileResponse, Http404
from django.core.paginator import Paginator
from django.views.generic import (
    CreateView,
    DeleteView,
    DetailView,
    ListView,
    TemplateView,
    UpdateView,
)

from .forms import (
    AssessmentForm,
    AttendanceForm,
    BatchForm,
    CertificateForm,
    ClientForm,
    CourseForm,
    EnrollmentForm,
    MaterialForm,
    ModuleForm,
    ProgramForm,
    SessionForm,
)
from .models import (
    Assessment,
    Attendance,
    Batch,
    Certificate,
    Client,
    Course,
    Enrollment,
    Material,
    Module,
    Program,
    Session,
)

# ─────────────────────────────────────────────
#  Login Page
# ─────────────────────────────────────────────
def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('dashboard')
        else:
            error = 'Invalid username or password'
            return render(request, 'login.html', {'error': error})
    return render(request, 'login.html')

@login_required
def dashboard_view(request):
    return render(request, 'SharedDashboard.html')

# ─────────────────────────────────────────────
#  Log out
# ─────────────────────────────────────────────
def logout_view(request):

    logout(request)
    return redirect('login')
# ─────────────────────────────────────────────
#  COURSES
# ─────────────────────────────────────────────
class CourseListView(ListView):
    model = Course
    template_name = 'courses/course_list.html'
    context_object_name = 'courses'

    def get_queryset(self):
        return Course.objects.prefetch_related('programs').all()

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['course_count']   = Course.objects.count()
        context['active_count']   = Course.objects.filter(status='Active').count()
        context['inactive_count'] = Course.objects.filter(status='Inactive').count()
        return context


def _generate_course_code():
    """Auto-generate course code like CRS-2026-0001."""
    import datetime
    year = datetime.date.today().year
    prefix = f'CRS-{year}-'
    last = (
        Course.objects.filter(course_code__startswith=prefix)
        .order_by('course_code').last()
    )
    if last:
        try:
            seq = int(last.course_code.split('-')[-1]) + 1
        except (ValueError, IndexError):
            seq = 1
    else:
        seq = 1
    return f'{prefix}{seq:04d}'


def _generate_batch_name(client, program, course, start_date, seq):
    def slug_text(value):
        text = str(value or '').upper()
        text = ''.join(ch for ch in text if ch.isalnum())
        return text

    year = start_date.year if start_date else datetime.date.today().year
    month = (start_date.strftime('%b').upper() if start_date else datetime.date.today().strftime('%b').upper())
    program_text = slug_text(program.program_name)
    course_text = slug_text(course.course_name)
    client_text = slug_text(client.client_name)
    return f'{year}_{month}_{program_text}_{course_text}_{client_text}_{seq:02d}'


class CourseCreateView(CreateView):
    model = Course
    form_class = CourseForm
    template_name = 'courses/course_form.html'
    success_url = reverse_lazy('course_list')

    def get_initial(self):
        initial = super().get_initial()
        initial['course_code'] = _generate_course_code()
        return initial

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['auto_code'] = _generate_course_code()
        context['programs']  = Program.objects.order_by('program_name')
        return context

    def form_valid(self, form):
        response = super().form_valid(form)
        # Link course to selected program via ProgramCourse
        from .models import ProgramCourse
        program_id = self.request.POST.get('program_id')
        if program_id:
            program = Program.objects.filter(pk=program_id).first()
            if program:
                seq = ProgramCourse.objects.filter(program=program).count() + 1
                ProgramCourse.objects.get_or_create(
                    program=program, course=self.object,
                    defaults={'sequence_no': seq}
                )
        return response


class CourseUpdateView(UpdateView):
    model = Course
    form_class = CourseForm
    template_name = 'courses/course_form.html'
    success_url = reverse_lazy('course_list')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['course']    = self.object
        context['auto_code'] = self.object.course_code
        context['programs']  = Program.objects.order_by('program_name')
        # Pre-select the first program this course belongs to
        first_pc = self.object.programs.first()
        context['selected_program_id'] = first_pc.pk if first_pc else None
        return context

    def form_valid(self, form):
        from .models import ProgramCourse
        response = super().form_valid(form)
        program_id = self.request.POST.get('program_id')
        if program_id:
            program = Program.objects.filter(pk=program_id).first()
            if program:
                seq = ProgramCourse.objects.filter(program=program).count() + 1
                ProgramCourse.objects.get_or_create(
                    program=program, course=self.object,
                    defaults={'sequence_no': seq}
                )
        return response


class CourseDeleteView(DeleteView):
    model = Course
    template_name = 'courses/course_delete.html'
    success_url = reverse_lazy('course_list')


class CourseSearchView(ListView):
    model = Course
    template_name = 'courses/search_course.html'
    context_object_name = 'courses'

    def get_queryset(self):
        query = self.request.GET.get('q', '').strip()
        if not query:
            return Course.objects.none()
        return Course.objects.filter(
            Q(course_name__icontains=query) | Q(course_code__icontains=query)
        )

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['query'] = self.request.GET.get('q', '').strip()
        return context


# ─────────────────────────────────────────────
#  PROGRAMS
# ─────────────────────────────────────────────
def _generate_program_code():
    """Auto-generate program code like PRG-2026-0001."""
    import datetime
    year = datetime.date.today().year
    prefix = f'PRG-{year}-'
    last = (
        Program.objects.filter(program_code__startswith=prefix)
        .order_by('program_code').last()
    )
    if last:
        try:
            seq = int(last.program_code.split('-')[-1]) + 1
        except (ValueError, IndexError):
            seq = 1
    else:
        seq = 1
    return f'{prefix}{seq:04d}'


class ProgramListView(ListView):
    model = Program
    template_name = 'programs/program_list.html'
    context_object_name = 'programs'

    def get_queryset(self):
        return Program.objects.select_related('client').all()

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['program_count']  = Program.objects.count()
        context['active_count']   = Program.objects.filter(status='Active').count()
        context['inactive_count'] = Program.objects.filter(status='Inactive').count()
        return context


class ProgramCreateView(CreateView):
    model = Program
    form_class = ProgramForm
    template_name = 'programs/program_form.html'
    success_url = reverse_lazy('program_list')

    def get_initial(self):
        initial = super().get_initial()
        initial['program_code'] = _generate_program_code()
        return initial

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['auto_code'] = _generate_program_code()
        return context


class ProgramUpdateView(UpdateView):
    model = Program
    form_class = ProgramForm
    template_name = 'programs/program_form.html'
    success_url = reverse_lazy('program_list')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['program']   = self.object
        context['auto_code'] = self.object.program_code
        return context


class ProgramDeleteView(DeleteView):
    model = Program
    template_name = 'programs/program_delete.html'
    success_url = reverse_lazy('program_list')


class ProgramDetailView(DetailView):
    model = Program
    template_name = 'programs/program_detail.html'
    context_object_name = 'program'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['courses'] = self.object.program_courses.select_related('course')
        return context


class ProgramSearchView(ListView):
    model = Program
    template_name = 'programs/program_search.html'
    context_object_name = 'programs'

    def get_queryset(self):
        query = self.request.GET.get('q', '').strip()
        if not query:
            return Program.objects.none()
        return Program.objects.filter(
            Q(program_name__icontains=query) | Q(program_code__icontains=query)
        ).select_related('client')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['query'] = self.request.GET.get('q', '').strip()
        return context


# ─────────────────────────────────────────────
#  CLIENTS
# ─────────────────────────────────────────────
class ClientListView(ListView):
    model = Client
    template_name = 'clients/client_list.html'
    context_object_name = 'clients'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['client_count']   = Client.objects.count()
        context['active_count']   = Client.objects.filter(status='Active').count()
        context['inactive_count'] = Client.objects.filter(status='Inactive').count()
        return context


def _generate_client_code():
    """Auto-generate client code like CLT-2026-0001."""
    import datetime
    year = datetime.date.today().year
    prefix = f'CLT-{year}-'
    last = (
        Client.objects.filter(client_code__startswith=prefix)
        .order_by('client_code')
        .last()
    )
    if last:
        try:
            seq = int(last.client_code.split('-')[-1]) + 1
        except (ValueError, IndexError):
            seq = 1
    else:
        seq = 1
    return f'{prefix}{seq:04d}'


class ClientCreateView(CreateView):
    model = Client
    form_class = ClientForm
    template_name = 'clients/client_form.html'
    success_url = reverse_lazy('client_list')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['programs']       = Program.objects.order_by('program_name')
        context['all_courses']    = Course.objects.filter(status='Active').order_by('course_name')
        context['auto_code']      = _generate_client_code()
        context['selected_program_ids'] = []
        return context

    def form_valid(self, form):
        response = super().form_valid(form)
        # Link selected programs to this client
        program_ids = self.request.POST.getlist('program_ids')
        if program_ids:
            Program.objects.filter(pk__in=program_ids).update(client=self.object)
        return response


class ClientUpdateView(UpdateView):
    model = Client
    form_class = ClientForm
    template_name = 'clients/client_form.html'
    success_url = reverse_lazy('client_list')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        linked_programs = Program.objects.filter(client=self.object)
        context['client']               = self.object
        context['programs']             = Program.objects.order_by('program_name')
        context['all_courses']          = Course.objects.filter(status='Active').order_by('course_name')
        context['auto_code']            = self.object.client_code
        context['selected_program_ids'] = list(linked_programs.values_list('pk', flat=True))
        return context

    def form_valid(self, form):
        response = super().form_valid(form)
        # Re-sync program assignments
        program_ids = self.request.POST.getlist('program_ids')
        Program.objects.filter(client=self.object).update(client=None)
        if program_ids:
            Program.objects.filter(pk__in=program_ids).update(client=self.object)
        return response


class ClientDeleteView(DeleteView):
    model = Client
    template_name = 'clients/client_delete.html'
    success_url = reverse_lazy('client_list')


class ClientSearchView(ListView):
    model = Client
    template_name = 'clients/client_search.html'
    context_object_name = 'clients'

    def get_queryset(self):
        query = self.request.GET.get('q', '').strip()
        if not query:
            return Client.objects.none()
        return Client.objects.filter(
            Q(client_name__icontains=query)
            | Q(client_code__icontains=query)
            | Q(contact_person__icontains=query)
            | Q(email__icontains=query)
        )

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['query'] = self.request.GET.get('q', '').strip()
        return context


# ─────────────────────────────────────────────
#  BATCHES
# ─────────────────────────────────────────────
class BatchListView(ListView):
    model = Batch
    template_name = 'batches/batch_list.html'
    context_object_name = 'batches'

    def get_queryset(self):
        return Batch.objects.select_related('client', 'program', 'course').all()

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['batch_count']    = Batch.objects.count()
        context['active_count']   = Batch.objects.filter(status='Active').count()
        context['inactive_count'] = Batch.objects.filter(status='Inactive').count()
        return context


class BatchCreateView(CreateView):
    model = Batch
    form_class = BatchForm
    template_name = 'batches/batch_form.html'
    success_url = reverse_lazy('batch_list')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['batch'] = None
        context['programs_data'] = json.dumps([
            {'id': p.id, 'name': p.program_name, 'client_id': p.client_id}
            for p in Program.objects.order_by('program_name')
        ])
        context['program_courses_map'] = json.dumps({
            str(p.id): [
                {'id': c.id, 'name': c.course_name, 'code': c.course_code}
                for c in Course.objects.filter(programs=p).order_by('course_name')
            ]
            for p in Program.objects.order_by('program_name')
        })
        context['today'] = datetime.date.today().isoformat()
        return context

    def form_valid(self, form):
        response = super().form_valid(form)
        client = self.object.client
        program = self.object.program
        course = self.object.course
        start_date = self.object.start_date or datetime.date.today()
        if client and program and course:
            seq = Batch.objects.filter(client=client, program=program, course=course).count() + 1
            self.object.batch_name = _generate_batch_name(client, program, course, start_date, seq)
            self.object.save()
        return response


class BatchUpdateView(UpdateView):
    model = Batch
    form_class = BatchForm
    template_name = 'batches/batch_form.html'
    success_url = reverse_lazy('batch_list')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['batch'] = self.object
        context['programs_data'] = json.dumps([
            {'id': p.id, 'name': p.program_name, 'client_id': p.client_id}
            for p in Program.objects.order_by('program_name')
        ])
        context['program_courses_map'] = json.dumps({
            str(p.id): [
                {'id': c.id, 'name': c.course_name, 'code': c.course_code}
                for c in Course.objects.filter(programs=p).order_by('course_name')
            ]
            for p in Program.objects.order_by('program_name')
        })
        context['selected_program_id'] = self.object.program_id
        context['selected_course_id'] = self.object.course_id
        context['today'] = self.object.start_date.isoformat() if self.object.start_date else datetime.date.today().isoformat()
        return context


class BatchDeleteView(DeleteView):
    model = Batch
    template_name = 'batches/batch_delete.html'
    success_url = reverse_lazy('batch_list')


# ─────────────────────────────────────────────
#  MODULES
# ─────────────────────────────────────────────
class ModuleListView(ListView):
    model = Module
    template_name = 'modules/module_list.html'
    context_object_name = 'modules'


class ModuleCreateView(CreateView):
    model = Module
    form_class = ModuleForm
    template_name = 'modules/module_form.html'
    success_url = reverse_lazy('module_list')


class ModuleUpdateView(UpdateView):
    model = Module
    form_class = ModuleForm
    template_name = 'modules/module_form.html'
    success_url = reverse_lazy('module_list')


class ModuleDeleteView(DeleteView):
    model = Module
    template_name = 'modules/module_delete.html'
    success_url = reverse_lazy('module_list')


# ─────────────────────────────────────────────
#  SESSIONS
# ─────────────────────────────────────────────
class SessionListView(ListView):
    model = Session
    template_name = 'sessions/session_list.html'
    context_object_name = 'sessions'


class SessionCreateView(CreateView):
    model = Session
    form_class = SessionForm
    template_name = 'sessions/session_form.html'
    success_url = reverse_lazy('session_list')


class SessionUpdateView(UpdateView):
    model = Session
    form_class = SessionForm
    template_name = 'sessions/session_form.html'
    success_url = reverse_lazy('session_list')


class SessionDeleteView(DeleteView):
    model = Session
    template_name = 'sessions/session_delete.html'
    success_url = reverse_lazy('session_list')


# ─────────────────────────────────────────────
#  ENROLLMENTS
# ─────────────────────────────────────────────
class EnrollmentListView(ListView):
    model = Enrollment
    template_name = 'enrollments/enrollment_list.html'
    context_object_name = 'enrollments'


class EnrollmentCreateView(CreateView):
    model = Enrollment
    form_class = EnrollmentForm
    template_name = 'enrollments/enrollment_form.html'
    success_url = reverse_lazy('enrollment_list')


class EnrollmentUpdateView(UpdateView):
    model = Enrollment
    form_class = EnrollmentForm
    template_name = 'enrollments/enrollment_form.html'
    success_url = reverse_lazy('enrollment_list')


class EnrollmentDeleteView(DeleteView):
    model = Enrollment
    template_name = 'enrollments/enrollment_delete.html'
    success_url = reverse_lazy('enrollment_list')


# ─────────────────────────────────────────────
#  MATERIALS
# ─────────────────────────────────────────────
@login_required
def material_list(request):
    query = request.GET.get('q', '').strip()
    material_type = request.GET.get('type', '').strip()
    course_id = request.GET.get('course', '').strip()
    module_id = request.GET.get('module', '').strip()

    materials = Material.objects.select_related('training_module', 'course')

    if query:
        materials = materials.filter(
            Q(title__icontains=query)
            | Q(material_code__icontains=query)
            | Q(course__course_name__icontains=query)
            | Q(training_module__name__icontains=query)
            | Q(material_type__icontains=query)
        )

    if material_type:
        materials = materials.filter(material_type=material_type)

    if course_id:
        materials = materials.filter(course_id=course_id)

    if module_id:
        materials = materials.filter(training_module_id=module_id)

    paginator = Paginator(materials.order_by('-created_at'), 12)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    context = {
        'materials': page_obj,
        'page_obj': page_obj,
        'search_query': query,
        'selected_type': material_type,
        'selected_course': course_id,
        'selected_module': module_id,
        'types': [choice[0] for choice in Material._meta.get_field('material_type').choices],
        'courses': Course.objects.order_by('course_name'),
        'modules': Module.objects.order_by('course__course_name', 'name'),
    }
    return render(request, 'materials/material_list.html', context)


@login_required
def material_create(request):
    if request.method == 'POST':
        form = MaterialForm(request.POST, request.FILES)
        if form.is_valid():
            material = form.save(commit=False)
            material.course = material.training_module.course
            material.save()
            return redirect('material_list')
    else:
        form = MaterialForm()

    return render(request, 'materials/material_upload.html', {
        'form': form,
        'page_title': 'Add Material',
        'submit_label': 'Save Material',
    })


@login_required
def material_edit(request, pk):
    material = get_object_or_404(Material, pk=pk)
    if request.method == 'POST':
        form = MaterialForm(request.POST, request.FILES, instance=material)
        if form.is_valid():
            updated = form.save(commit=False)
            updated.course = updated.training_module.course
            updated.save()
            return redirect('material_detail', pk=material.pk)
    else:
        form = MaterialForm(instance=material)

    return render(request, 'materials/material_upload.html', {
        'form': form,
        'material': material,
        'page_title': 'Edit Material',
        'submit_label': 'Update Material',
    })


@login_required
def material_detail(request, pk):
    material = get_object_or_404(Material, pk=pk)
    return render(request, 'materials/material_detail.html', {'material': material})


@login_required
def material_delete(request, pk):
    material = get_object_or_404(Material, pk=pk)
    if request.method == 'POST':
        material.is_deleted = True
        material.save()
        return redirect('material_list')
    return render(request, 'materials/material_delete.html', {'material': material})


@login_required
def material_download(request, pk):
    material = get_object_or_404(Material, pk=pk)
    if not material.uploaded_file:
        raise Http404('No file available for download.')
    file_path = material.uploaded_file.path
    if not os.path.exists(file_path):
        raise Http404('File not found.')
    return FileResponse(open(file_path, 'rb'), as_attachment=True, filename=os.path.basename(file_path))


# ─────────────────────────────────────────────
#  CERTIFICATES
# ─────────────────────────────────────────────
class CertificateListView(ListView):
    model = Certificate
    template_name = 'certificates/certificate_list.html'
    context_object_name = 'certificates'


class CertificateCreateView(CreateView):
    model = Certificate
    form_class = CertificateForm
    template_name = 'certificates/generate_certificate.html'
    success_url = reverse_lazy('certificate_list')


# ─────────────────────────────────────────────
#  ASSESSMENTS
# ─────────────────────────────────────────────
class AssessmentListView(ListView):
    model = Assessment
    template_name = 'assessments/assessment_list.html'
    context_object_name = 'assessments'


class AssessmentCreateView(CreateView):
    model = Assessment
    form_class = AssessmentForm
    template_name = 'assessments/assessment_form.html'
    success_url = reverse_lazy('assessment_list')


class AssessmentUpdateView(UpdateView):
    model = Assessment
    form_class = AssessmentForm
    template_name = 'assessments/assessment_form.html'
    success_url = reverse_lazy('assessment_list')


class AssessmentDeleteView(DeleteView):
    model = Assessment
    template_name = 'assessments/assessment_delete.html'
    success_url = reverse_lazy('assessment_list')


class ResultListView(ListView):
    model = Assessment
    template_name = 'assessments/result_list.html'
    context_object_name = 'assessments'


# ─────────────────────────────────────────────
#  ATTENDANCE
# ─────────────────────────────────────────────
class AttendanceListView(ListView):
    model = Attendance
    template_name = 'attendance/attedance_list.html'
    context_object_name = 'attendances'


class MarkAttendanceView(CreateView):
    model = Attendance
    form_class = AttendanceForm
    template_name = 'attendance/mark_attendance.html'
    success_url = reverse_lazy('attendance_list')


class AttendanceReportView(TemplateView):
    template_name = 'attendance/attendance_report.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['attendances'] = Attendance.objects.order_by('-date')
        return context


# ─────────────────────────────────────────────
#  SHARED SERVICES
# ─────────────────────────────────────────────
class SharedDashboardView(TemplateView):
    template_name = 'shared/dashboard.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context.update({
            'course_count':   Course.objects.count(),
            'program_count':  Program.objects.count(),
            'client_count':   Client.objects.count(),
            'batch_count':    Batch.objects.count(),
            'session_count':  Session.objects.count(),
            'attendance_count': Attendance.objects.count(),
        })
        return context


class SharedReportsView(TemplateView):
    template_name = 'shared/reports.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['recent_programs'] = Program.objects.select_related('client').order_by('-id')[:5]
        context['recent_courses']  = Course.objects.order_by('-id')[:5]
        return context


class SharedNotificationsView(TemplateView):
    template_name = 'shared/notifications.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['notifications'] = [
            {'title': 'System maintenance scheduled',   'date': '2026-06-10'},
            {'title': 'New course material uploaded',   'date': '2026-06-03'},
            {'title': 'Attendance report ready',        'date': '2026-06-02'},
        ]
        return context


class SharedAuditLogView(TemplateView):
    template_name = 'shared/audit_logs.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['logs'] = [
            {'time': '2026-06-03 10:15', 'action': 'Created new course',       'user': 'admin'},
            {'time': '2026-06-02 16:40', 'action': 'Updated program details',  'user': 'trainer'},
            {'time': '2026-06-01 09:12', 'action': 'Marked attendance',        'user': 'staff'},
        ]
        return context