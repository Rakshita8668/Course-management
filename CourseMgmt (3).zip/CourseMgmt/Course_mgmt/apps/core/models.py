import uuid
from django.db import models
from django.urls import reverse
from django.utils import timezone


STATUS_CHOICES = [
    ('Active', 'Active'),
    ('Inactive', 'Inactive'),
]
SESSION_STATUS_CHOICES = [
    ('Scheduled', 'Scheduled'),
    ('Active', 'Active'),
    ('Completed', 'Completed'),
    ('Cancelled', 'Cancelled'),
]
PROGRAM_TYPE_CHOICES = [
    ('skill_building', 'Skill Building'),
    ('credit_transfer', 'Credit Transfer'),
    ('training_of_trainers', 'Training of Trainers'),
    ('corporate_training', 'Corporate Training'),
    ('fdp', 'FDP'),
    ('internship', 'Internship'),
]
PROGRAM_STATUS_CHOICES = [
    ('Active', 'Active'),
    ('Inactive', 'Inactive'),
    ('Completed', 'Completed'),
    ('Draft', 'Draft'),
]
DELIVERY_MODE_CHOICES = [
    ('Online', 'Online'),
    ('Offline', 'Offline'),
    ('Hybrid', 'Hybrid'),
]
ORG_TYPE_CHOICES = [
    ('College', 'College'),
    ('University', 'University'),
    ('Corporate', 'Corporate'),
    ('Government', 'Government'),
    ('Training Institute', 'Training Institute'),
    ('School', 'School'),
    ('Other', 'Other'),
]


class Client(models.Model):
    client_code     = models.CharField(max_length=32, unique=True)
    client_name     = models.CharField(max_length=255)
    org_type        = models.CharField(max_length=64, choices=ORG_TYPE_CHOICES, blank=True)
    contact_person  = models.CharField(max_length=255, blank=True)
    designation     = models.CharField(max_length=255, blank=True)
    email           = models.EmailField(blank=True)
    phone           = models.CharField(max_length=32, blank=True)
    address         = models.TextField(blank=True)
    city            = models.CharField(max_length=128, blank=True)
    state           = models.CharField(max_length=128, blank=True)
    pincode         = models.CharField(max_length=10, blank=True)
    status          = models.CharField(max_length=16, choices=STATUS_CHOICES, default='Active')
    notes           = models.TextField(blank=True)
    created_at      = models.DateTimeField(default=timezone.now)

    class Meta:
        ordering = ['client_name']

    def __str__(self):
        return self.client_name

    def get_absolute_url(self):
        return reverse('client_list')


class Course(models.Model):
    course_code     = models.CharField(max_length=32, unique=True)
    course_name     = models.CharField(max_length=255)
    level           = models.CharField(max_length=64, blank=True)
    duration_hours  = models.PositiveIntegerField(default=0)
    fees            = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    delivery_mode   = models.CharField(max_length=16, choices=DELIVERY_MODE_CHOICES, blank=True)
    status          = models.CharField(max_length=16, choices=STATUS_CHOICES, default='Active')
    description     = models.TextField(blank=True)

    @property
    def primary_program_name(self):
        first_program = self.programs.first()
        return first_program.program_name if first_program else ''

    class Meta:
        ordering = ['course_code']

    def __str__(self):
        return self.course_name

    def get_absolute_url(self):
        return reverse('course_list')


class Program(models.Model):
    program_code    = models.CharField(max_length=32, unique=True)
    program_name    = models.CharField(max_length=255)
    category        = models.CharField(max_length=128, blank=True)
    program_type    = models.CharField(max_length=32, choices=PROGRAM_TYPE_CHOICES, blank=True)
    duration_days   = models.PositiveIntegerField(default=0)
    start_date      = models.DateField(null=True, blank=True)
    end_date        = models.DateField(null=True, blank=True)
    status          = models.CharField(max_length=16, choices=PROGRAM_STATUS_CHOICES, default='Active')
    description     = models.TextField(blank=True)
    client          = models.ForeignKey(
                        Client, on_delete=models.SET_NULL,
                        null=True, blank=True, related_name='programs'
                      )
    created_at      = models.DateTimeField(default=timezone.now)
    courses         = models.ManyToManyField(Course, through='ProgramCourse', related_name='programs')

    class Meta:
        ordering = ['program_code']

    def __str__(self):
        return self.program_name

    def get_absolute_url(self):
        return reverse('program_list')


class ProgramCourse(models.Model):
    program     = models.ForeignKey(Program, on_delete=models.CASCADE, related_name='program_courses')
    course      = models.ForeignKey(Course, on_delete=models.PROTECT)
    sequence_no = models.PositiveIntegerField(default=1)

    class Meta:
        ordering = ['sequence_no']
        unique_together = ('program', 'course')

    def __str__(self):
        return f'{self.program} – {self.course}'


class Batch(models.Model):
    batch_name  = models.CharField(max_length=255)
    client      = models.ForeignKey(
                    Client, on_delete=models.SET_NULL,
                    null=True, blank=True, related_name='batches'
                  )
    program     = models.ForeignKey(
                    Program, on_delete=models.SET_NULL,
                    null=True, blank=True, related_name='batches'
                  )
    course      = models.ForeignKey(Course, on_delete=models.CASCADE, related_name='batches')
    capacity    = models.PositiveIntegerField(default=0)
    start_date  = models.DateField()
    end_date    = models.DateField()
    status      = models.CharField(max_length=16, choices=STATUS_CHOICES, default='Active')
    remarks     = models.TextField(blank=True)

    class Meta:
        ordering = ['start_date']

    def __str__(self):
        return self.batch_name

    def get_absolute_url(self):
        return reverse('batch_list')


class Module(models.Model):
    course          = models.ForeignKey(Course, on_delete=models.CASCADE, related_name='modules')
    name            = models.CharField(max_length=255)
    duration_hours  = models.PositiveIntegerField(default=0)
    status          = models.CharField(max_length=16, choices=STATUS_CHOICES, default='Active')
    description     = models.TextField(blank=True)

    class Meta:
        ordering = ['course', 'name']

    def __str__(self):
        return self.name

    def get_absolute_url(self):
        return reverse('module_list')


class Session(models.Model):
    course      = models.ForeignKey(Course, on_delete=models.CASCADE, related_name='sessions')
    title       = models.CharField(max_length=255)
    instructor  = models.CharField(max_length=128, blank=True)
    start_date  = models.DateField()
    end_date    = models.DateField()
    status      = models.CharField(max_length=16, choices=SESSION_STATUS_CHOICES, default='Scheduled')
    notes       = models.TextField(blank=True)

    class Meta:
        ordering = ['-start_date']

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse('session_list')


class Enrollment(models.Model):
    student_name    = models.CharField(max_length=255)
    course          = models.ForeignKey(Course, on_delete=models.CASCADE, related_name='enrollments')
    enrollment_date = models.DateField()
    status          = models.CharField(max_length=16, choices=STATUS_CHOICES, default='Active')

    class Meta:
        ordering = ['-enrollment_date']

    def __str__(self):
        return f'{self.student_name} – {self.course}'

    def get_absolute_url(self):
        return reverse('enrollment_list')


class MaterialQuerySet(models.QuerySet):
    def active(self):
        return self.filter(is_deleted=False)

    def external(self):
        return self.filter(uploaded_file='')

    def uploaded(self):
        return self.exclude(uploaded_file='')


class MaterialManager(models.Manager):
    def get_queryset(self):
        return MaterialQuerySet(self.model, using=self._db).filter(is_deleted=False)

    def all_objects(self):
        return super().get_queryset()


class Material(models.Model):
    material_id      = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    material_code    = models.CharField(max_length=32, unique=True, editable=False)
    course           = models.ForeignKey(Course, on_delete=models.CASCADE, related_name='materials')
    training_module  = models.ForeignKey('Module', on_delete=models.CASCADE, related_name='materials')
    title            = models.CharField(max_length=255)
    description      = models.TextField(blank=True)
    material_type    = models.CharField(max_length=64, choices=[
        ('PDF', 'PDF'),
        ('PPT', 'PPT'),
        ('Document', 'Document'),
        ('Video', 'Video'),
        ('YouTube', 'YouTube'),
        ('Official Documentation', 'Official Documentation'),
        ('GitHub Repository', 'GitHub Repository'),
        ('Online Course', 'Online Course'),
        ('Research Paper', 'Research Paper'),
        ('Website', 'Website'),
        ('Assignment', 'Assignment'),
        ('Dataset', 'Dataset'),
    ])
    resource_url     = models.URLField(blank=True)
    uploaded_file    = models.FileField(upload_to='materials/uploads/', blank=True)
    author           = models.CharField(max_length=128, blank=True)
    status           = models.CharField(max_length=16, choices=STATUS_CHOICES, default='Active')
    created_at       = models.DateTimeField(auto_now_add=True)
    updated_at       = models.DateTimeField(auto_now=True)
    is_deleted       = models.BooleanField(default=False)

    objects = MaterialManager()

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse('material_list')

    @staticmethod
    def generate_material_code():
        year = timezone.now().year
        prefix = f'MAT-{year}-'
        last = Material.objects.all_objects().filter(material_code__startswith=prefix).order_by('material_code').last()
        if last:
            try:
                seq = int(last.material_code.split('-')[-1]) + 1
            except (ValueError, IndexError):
                seq = 1
        else:
            seq = 1
        return f'{prefix}{seq:04d}'

    def save(self, *args, **kwargs):
        if self.training_module and self.course != self.training_module.course:
            self.course = self.training_module.course
        if not self.material_code:
            self.material_code = self.generate_material_code()
        super().save(*args, **kwargs)


class Certificate(models.Model):
    student_name    = models.CharField(max_length=255)
    course          = models.ForeignKey(Course, on_delete=models.CASCADE, related_name='certificates')
    issue_date      = models.DateField()
    remarks         = models.TextField(blank=True)

    class Meta:
        ordering = ['-issue_date']

    def __str__(self):
        return f'Certificate: {self.student_name} – {self.course}'

    def get_absolute_url(self):
        return reverse('certificate_list')


class Assessment(models.Model):
    course          = models.ForeignKey(Course, on_delete=models.CASCADE, related_name='assessments')
    name            = models.CharField(max_length=255)
    total_marks     = models.PositiveIntegerField(default=100)
    status          = models.CharField(max_length=16, choices=STATUS_CHOICES, default='Active')
    scheduled_date  = models.DateField(blank=True, null=True)

    class Meta:
        ordering = ['-scheduled_date']

    def __str__(self):
        return self.name

    def get_absolute_url(self):
        return reverse('assessment_list')


class Attendance(models.Model):
    session         = models.ForeignKey(Session, on_delete=models.CASCADE, related_name='attendances')
    date            = models.DateField()
    present_count   = models.PositiveIntegerField(default=0)
    absent_count    = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ['-date']

    def __str__(self):
        return f'Attendance for {self.session} on {self.date}'

    def get_absolute_url(self):
        return reverse('attendance_report')