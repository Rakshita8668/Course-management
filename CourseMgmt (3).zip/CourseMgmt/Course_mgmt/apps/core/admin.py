from django.contrib import admin

from .models import (
    Assessment,
    Attendance,
    Batch,
    Certificate,
    Client,
    Course,
    Enrollment,
    Material,
    Module,
    Program,
    ProgramCourse,
    Session,
)


@admin.register(Client)
class ClientAdmin(admin.ModelAdmin):
    list_display = ('client_code', 'client_name', 'contact_person', 'email', 'status')
    search_fields = ('client_code', 'client_name', 'contact_person')


@admin.register(Course)
class CourseAdmin(admin.ModelAdmin):
    list_display = ('course_code', 'course_name', 'level', 'duration_hours', 'status')
    search_fields = ('course_code', 'course_name')


@admin.register(Program)
class ProgramAdmin(admin.ModelAdmin):
    list_display = ('program_code', 'program_name', 'client', 'category', 'duration_days', 'status')
    search_fields = ('program_code', 'program_name')


@admin.register(ProgramCourse)
class ProgramCourseAdmin(admin.ModelAdmin):
    list_display = ('program', 'course', 'sequence_no')
    list_filter = ('program',)


@admin.register(Module)
class ModuleAdmin(admin.ModelAdmin):
    list_display = ('name', 'course', 'duration_hours', 'status')
    search_fields = ('name',)


@admin.register(Session)
class SessionAdmin(admin.ModelAdmin):
    list_display = ('title', 'course', 'start_date', 'end_date', 'status')
    search_fields = ('title', 'course__course_name')


@admin.register(Batch)
class BatchAdmin(admin.ModelAdmin):
    list_display = ('batch_name', 'course', 'start_date', 'end_date', 'status')


@admin.register(Enrollment)
class EnrollmentAdmin(admin.ModelAdmin):
    list_display = ('student_name', 'course', 'enrollment_date', 'status')


@admin.register(Material)
class MaterialAdmin(admin.ModelAdmin):
    list_display = ('material_code', 'title', 'course', 'training_module', 'material_type', 'status', 'created_at')
    search_fields = ('material_code', 'title', 'course__course_name', 'training_module__name')
    list_filter = ('material_type', 'status', 'course')


@admin.register(Certificate)
class CertificateAdmin(admin.ModelAdmin):
    list_display = ('student_name', 'course', 'issue_date')


@admin.register(Assessment)
class AssessmentAdmin(admin.ModelAdmin):
    list_display = ('name', 'course', 'total_marks', 'status')


@admin.register(Attendance)
class AttendanceAdmin(admin.ModelAdmin):
    list_display = ('session', 'date', 'present_count', 'absent_count')
